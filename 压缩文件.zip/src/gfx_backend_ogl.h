#pragma once

#include "gfx_interface.h"

struct fln_gfx_backend_t fln_gfx_init_backend_ogl();