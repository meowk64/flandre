#pragma once

#include <lua.h>
#define FLN_USERTYPE_TRANSFORM "fln.transform"

int fln_luaopen_math(lua_State * L);
