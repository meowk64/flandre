#pragma once

#include <lua.h>

int fln_luaopen(lua_State *);